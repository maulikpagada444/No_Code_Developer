import { Routes, Route, Navigate } from 'react-router-dom';
import Home from './Components/Home/Home';
import { ThemeProvider } from './ThemeProvider';
import SignUpFlow from './Components/SignUp/SignUpFlow';
import SignInFlow from './Components/SignIn/SignInFlow';

function App() {
  return (
    <ThemeProvider>

      <Routes>
        <Route path="/" element={<Navigate to="/home" replace />} />
        <Route path="/home" element={<Home />} />

        <Route path="/signup" element={<SignUpFlow />} />
        <Route path="/signin" element={<SignInFlow />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;
